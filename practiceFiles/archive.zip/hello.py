def main():
    print("Hello")
    name = input("what is your name? ")
    print("nice to meet you", name)


if __name__ == "__main__":
    main()
