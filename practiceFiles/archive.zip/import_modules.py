import math

print("the squareroot of 16 is" , math.sqrt(16))

print("Pi is", math.pi)

